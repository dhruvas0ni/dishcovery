//
//  ViewController.swift
//  Dishcovery
//
//  Created by Student on 15/04/25.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    var flag = 0
    @IBAction func buttonTapped1(_ sender: Any) {
        flag = 1
        performSegue(withIdentifier: "2nd", sender: nil)
    }
    
    @IBAction func buttonTapped2(_ sender: Any) {
        flag = 2
        performSegue(withIdentifier: "2nd", sender: nil)
    }
    
    @IBAction func buttonTapped3(_ sender: Any) {
        flag = 3
        performSegue(withIdentifier: "2nd", sender: nil)
    }
    
    @IBAction func buttonTapped4(_ sender: Any) {
        flag = 4
        performSegue(withIdentifier: "2nd", sender: nil)
    }
    
    @IBAction func buttonTapped5(_ sender: Any) {
        flag = 5
        performSegue(withIdentifier: "2nd", sender: nil)
    }
    
    
    @IBAction func buttonTapped6(_ sender: Any) {
        flag = 6
        performSegue(withIdentifier: "2nd", sender: nil)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var obj = segue.destination as! secondViewController
        obj.flag2 = flag
    }
    
}

