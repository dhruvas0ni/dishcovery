//
//  secondViewController.swift
//  Dishcovery
//
//  Created by Student on 22/04/25.
//

import UIKit

class secondViewController: UIViewController {

    
    var name : String = ""
    override func viewDidLoad() {
        super.viewDidLoad()
       
        
        // Do any additional setup after loading the view.
        print(flag2)
        if (flag2 == 1) {
            img.image = UIImage(named: "Image 1")
            lbl.text = "Matar Paneer"
            selectedVideoURL = URL(string: "https://youtu.be/SbOA2GcJOf0?si=yqGgk9FM0oV5y-DW")
            ing.text = """
            Ingredients:
            - Paneer – 200g (cubed)
            - Green peas – 1 cup
            - Onion – 1 large (chopped)
            - Tomato – 2 large (pureed)
            - Ginger-garlic paste – 1 tsp
            - Green chili – 1 (optional)
            - Cumin seeds – 1 tsp
            - Turmeric – ½ tsp
            - Red chili powder – 1 tsp
            - Coriander powder – 1 tsp
            - Garam masala – ½ tsp
            - Salt – to taste
            - Oil/ghee – 2 tbsp
            - Cream – 2 tbsp (optional)
            - Fresh coriander – for garnish

            Steps:
            1. Heat oil and add cumin seeds. Let them splutter.
            2. Sauté onion till golden. Add ginger-garlic paste and green chili.
            3. Add tomato puree, turmeric, chili powder, and coriander powder. Cook till oil separates.
            4. Add peas and cook 3–4 minutes.
            5. Add paneer cubes, salt, and 1 cup water. Simmer for 10 minutes.
            6. Add garam masala and cream. Cook for 2 minutes.
            7. Garnish with coriander. Serve hot.
            """
        }

        else if (flag2 == 2) {
            img.image = UIImage(named: "Image 2")
            lbl.text = "Palak Paneer"
            selectedVideoURL = URL(string: "https://m.youtube.com/watch?v=5lVLxEr_qgM&pp=ygUaUGFsYWsgcGFubmVyIHJhbnZlZXIgYmFyYXI%3D")
            ing.text = """
            Ingredients:
            - Spinach (Palak) – 300g
            - Paneer – 200g (cubed)
            - Onion – 1 (chopped)
            - Tomato – 1 (chopped)
            - Ginger-garlic paste – 1 tsp
            - Green chili – 1
            - Cumin seeds – 1 tsp
            - Garam masala – ½ tsp
            - Turmeric – ¼ tsp
            - Salt – to taste
            - Cream – 2 tbsp (optional)
            - Oil/ghee – 2 tbsp

            Steps:
            1. Blanch spinach in hot water for 2 minutes. Drain, cool, and blend to a paste.
            2. Heat oil, add cumin, then sauté onion, chili, and ginger-garlic paste.
            3. Add tomato, turmeric, salt, and cook till soft.
            4. Add spinach puree and cook for 5–6 minutes.
            5. Add paneer and simmer for 5 minutes.
            6. Finish with cream and garam masala.
            7. Serve with roti or rice.
            """
        }

        else if (flag2 == 3) {
            img.image = UIImage(named: "Image 3")
            lbl.text = "Dal Tadka"
            selectedVideoURL = URL(string: "https://m.youtube.com/watch?v=3XTSCbZfEgM&pp=ygUXZGFsIHRhZGthIHJhbnZlZXIgYmFyYXI%3D")
            ing.text = """
            Ingredients:
            - Toor dal – 1 cup
            - Onion – 1
            - Tomato – 1
            - Ginger-garlic paste – 1 tsp
            - Green chili – 1
            - Turmeric – ½ tsp
            - Mustard seeds – ½ tsp
            - Cumin – ½ tsp
            - Dry red chilies – 2
            - Hing (asafoetida) – pinch
            - Ghee – 2 tbsp
            - Salt – to taste
            - Coriander – for garnish

            Steps:
            1. Pressure cook dal with turmeric and 2 cups water. Mash and set aside.
            2. In a pan, heat ghee, add mustard, cumin, chilies, and hing.
            3. Add onion, chili, and ginger-garlic paste. Cook till golden.
            4. Add tomato and salt. Cook till soft.
            5. Add cooked dal and simmer for 5–7 minutes.
            6. Garnish with coriander and serve hot.
            """
        }

        else if (flag2 == 4) {
            img.image = UIImage(named: "Image 4")
            lbl.text = "Amritsari Chole Bhature"
            selectedVideoURL = URL(string: "https://m.youtube.com/watch?v=_e1hHIbdBUw&pp=ygUkQW1yaXRzYXJpIGNob2xlIGJhdHVyYSByYW52ZWVyICBiYXJh")
            ing.text = """
            Ingredients (Chole):
            - Chickpeas – 1 cup (soaked overnight)
            - Onion – 1
            - Tomato – 2
            - Ginger-garlic paste – 1 tsp
            - Tea bag – 1 (optional for color)
            - Chole masala – 2 tsp
            - Turmeric – ½ tsp
            - Red chili – 1 tsp
            - Cumin seeds – 1 tsp
            - Salt – to taste
            - Oil – 2 tbsp

            Ingredients (Bhature):
            - All-purpose flour – 2 cups
            - Yogurt – ¼ cup
            - Baking soda – ¼ tsp
            - Salt – ½ tsp
            - Water – as needed
            - Oil – for deep frying

            Steps (Chole):
            1. Pressure cook chickpeas with tea bag and salt.
            2. Heat oil, sauté cumin, onion, and ginger-garlic paste.
            3. Add tomatoes and spices. Cook till oil leaves.
            4. Add chickpeas and simmer for 15 minutes.

            Steps (Bhature):
            1. Mix flour, salt, yogurt, and soda. Knead to soft dough.
            2. Rest for 2–3 hours. Roll into discs.
            3. Deep fry till golden and puffed.
            """
        }

        else if (flag2 == 5) {
            img.image = UIImage(named: "Image 5")
            lbl.text = "Rajma Masala"
            selectedVideoURL = URL(string: "https://m.youtube.com/watch?v=e7N93e5dKtM&pp=ygUaUmFqbWEgbWFzYWxhIHJhbnZlZXIgYmFyYXI%3D")
            ing.text = """
            Ingredients:
            - Kidney beans – 1 cup (soaked overnight)
            - Onion – 1
            - Tomato – 2
            - Ginger-garlic paste – 1 tsp
            - Cumin – 1 tsp
            - Turmeric – ½ tsp
            - Red chili – 1 tsp
            - Coriander powder – 1 tsp
            - Garam masala – ½ tsp
            - Salt – to taste
            - Oil – 2 tbsp

            Steps:
            1. Pressure cook rajma with salt until soft.
            2. Heat oil, add cumin, onion, ginger-garlic paste. Cook till golden.
            3. Add tomato and spices. Cook till oil separates.
            4. Add rajma with some water and simmer 15–20 minutes.
            5. Serve with rice.
            """
        }

        else if (flag2 == 6) {
            img.image = UIImage(named: "Image 6")
            lbl.text = "Baingan Bharta"
            selectedVideoURL = URL(string: "https://m.youtube.com/watch?v=yRZKfDI28Ro&pp=ygUXQmdhbiBiYXJ0aGEgcmFudmVyIGJyYXI%3D")
            ing.text = """
            Ingredients:
            - Eggplant – 1 large
            - Onion – 1
            - Tomato – 2
            - Garlic – 4 cloves
            - Green chili – 1
            - Oil – 2 tbsp
            - Salt – to taste
            - Cumin seeds – ½ tsp
            - Coriander – for garnish

            Steps:
            1. Roast eggplant on flame until charred. Peel and mash.
            2. Heat oil, sauté cumin, garlic, and onion.
            3. Add tomato, chili, and salt. Cook till soft.
            4. Add mashed eggplant. Mix and cook 5–7 minutes.
            5. Garnish with coriander and serve.
            """
        }

    }
    var flag2 = 0
    var selectedVideoURL: URL?
    
    @IBOutlet weak var img: UIImageView!
    
    @IBOutlet weak var lbl: UILabel!
    
    @IBOutlet weak var ing: UITextView!
    
    @IBAction func openYouTubeVideo(_ sender: UIButton) {
        if let url = selectedVideoURL {
                    UIApplication.shared.open(url, options: [:], completionHandler: nil)

                    // Or use SafariViewController if preferred:
                    // let safariVC = SFSafariViewController(url: url)
                    // present(safariVC, animated: true, completion: nil)
                } else {
                    print("Video URL not set.")
                }
        
    }
}
